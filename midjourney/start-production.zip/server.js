const express = require('express');
const cors = require('cors');
const PuppeteerMidjourneyAPI = require('./puppeteer-client.js');

const app = express();
const PORT = 3002;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

let client = null;
let isInitializing = false;
let healthStatus = {
  status: 'stopped',
  uptime: 0,
  totalRequests: 0,
  successfulRequests: 0,
  failedRequests: 0,
  lastRequest: null,
  lastError: null
};

function buildFullPrompt(prompt, options = {}) {
  const {
    chaos = 5,
    ar = '4:3',
    stylize = 150,
    weird = 200,
    version = 7,
    quality = 'normal',
    stop = null,
    tile = false,
    niji = false,
    mode = 'relaxed',
    private: isPrivate = false
  } = options;

  let fullPrompt = prompt;
  
  fullPrompt += ` --chaos ${chaos}`;
  fullPrompt += ` --ar ${ar}`;
  fullPrompt += ` --stylize ${stylize}`;
  fullPrompt += ` --weird ${weird}`;
  fullPrompt += ` --v ${version}`;
  
  if (quality !== 'normal') {
    fullPrompt += ` --q ${quality}`;
  }
  
  if (stop) {
    fullPrompt += ` --stop ${stop}`;
  }
  
  if (tile) {
    fullPrompt += ' --tile';
  }
  
  if (niji) {
    fullPrompt += ' --niji';
  }

  return fullPrompt;
}

async function initializeClient() {
  if (isInitializing) {
    console.log('⏳ Client đang được khởi tạo...');
    return;
  }

  isInitializing = true;
  try {
    console.log('🚀 Đang khởi tạo Puppeteer client...');
    client = new PuppeteerMidjourneyAPI();
    await client.initBrowser();
    
    const authStatus = await client.checkAuthStatus();
    if (!authStatus.isLoggedIn) {
      throw new Error('Không thể đăng nhập vào Midjourney');
    }
    
    healthStatus.status = 'running';
    healthStatus.uptime = Date.now();
    console.log('✅ Client đã được khởi tạo thành công!');
  } catch (error) {
    console.error('❌ Lỗi khởi tạo client:', error.message);
    healthStatus.status = 'error';
    healthStatus.lastError = error.message;
    throw error;
  } finally {
    isInitializing = false;
  }
}

async function gracefulShutdown() {
  console.log('🛑 Đang tắt server...');
  if (client) {
    try {
      await client.closeBrowser();
      console.log('✅ Browser đã được đóng');
    } catch (error) {
      console.error('❌ Lỗi đóng browser:', error.message);
    }
  }
  process.exit(0);
}

app.get('/health', (req, res) => {
  const uptime = healthStatus.uptime ? Date.now() - healthStatus.uptime : 0;
  res.json({
    status: healthStatus.status,
    uptime: Math.floor(uptime / 1000), 
    totalRequests: healthStatus.totalRequests,
    successfulRequests: healthStatus.successfulRequests,
    failedRequests: healthStatus.failedRequests,
    successRate: healthStatus.totalRequests > 0 ? 
      Math.round((healthStatus.successfulRequests / healthStatus.totalRequests) * 100) : 0,
    lastRequest: healthStatus.lastRequest,
    lastError: healthStatus.lastError,
    timestamp: new Date().toISOString()
  });
});

app.post('/midjourney/init', async (req, res) => {
  try {
    await initializeClient();
    res.json({
      success: true,
      message: 'Client đã được khởi tạo thành công',
      status: healthStatus.status
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

app.post('/midjourney/genimage', async (req, res) => {
  healthStatus.totalRequests++;
  healthStatus.lastRequest = new Date().toISOString();
  
  try {
    const { prompt, url_image, options = {} } = req.body;
    
    if (!prompt) {
      throw new Error('Prompt là bắt buộc');
    }

    console.log('🎨 Nhận yêu cầu generate ảnh:');
    console.log('📝 Prompt:', prompt);
    console.log('⚙️ Options:', options);

    if (!client || healthStatus.status !== 'running') {
      console.log('🔄 Client chưa sẵn sàng, đang khởi tạo...');
      await initializeClient();
    }

    const fullPrompt = await client.createPrompt(url_image, prompt, options);
    console.log('📝 Full prompt:', fullPrompt);

    const result = await client.generateImageRealistic(fullPrompt, options);
    
    if (result.success) {
      healthStatus.successfulRequests++;
      res.json({
        success: true,
        message: result.message,
        data: result.data,
        retryCount: result.retryCount,
        timestamp: new Date().toISOString()
      });
    } else {
      healthStatus.failedRequests++;
      res.status(500).json({
        success: false,
        error: result.error,
        retryCount: result.retryCount,
        timestamp: new Date().toISOString()
      });
    }

  } catch (error) {
    healthStatus.failedRequests++;
    healthStatus.lastError = error.message;
    console.error('❌ Lỗi generate ảnh:', error.message);
    res.status(500).json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

app.get('/midjourney/genimage', async (req, res) => {
  healthStatus.totalRequests++;
  healthStatus.lastRequest = new Date().toISOString();
  
  try {
    const { prompt, url_image, chaos, ar, stylize, weird, version, quality, stop, tile, niji, mode, private: isPrivate } = req.query;
    
    if (!prompt) {
      throw new Error('Prompt là bắt buộc');
    }

    console.log('🎨 Nhận yêu cầu generate ảnh:');
    console.log('📝 Prompt:', prompt);
    
    const options = {};
    if (chaos) options.chaos = parseInt(chaos);
    if (ar) options.ar = ar;
    if (stylize) options.stylize = parseInt(stylize);
    if (weird) options.weird = parseInt(weird);
    if (version) options.version = parseInt(version);
    if (quality) options.quality = parseFloat(quality);
    if (stop) options.stop = parseInt(stop);
    if (tile) options.tile = tile === 'true';
    if (niji) options.niji = parseInt(niji);
    if (mode) options.mode = mode;
    if (isPrivate) options.private = isPrivate === 'true';
    
    console.log('⚙️ Options:', options);

    if (!client || healthStatus.status !== 'running') {
      console.log('🔄 Client chưa sẵn sàng, đang khởi tạo...');
      await initializeClient();
    }

    const fullPrompt = await client.createPrompt(url_image, prompt, options);
    console.log('📝 Full prompt:', fullPrompt);

    const result = await client.generateImageRealistic(fullPrompt, options);
    
    if (result.success) {
      healthStatus.successfulRequests++;
      res.json({
        success: true,
        message: result.message,
        data: result.data,
        retryCount: result.retryCount,
        timestamp: new Date().toISOString()
      });
    } else {
      healthStatus.failedRequests++;
      res.status(500).json({
        success: false,
        error: result.error,
        retryCount: result.retryCount,
        timestamp: new Date().toISOString()
      });
    }

  } catch (error) {
    healthStatus.failedRequests++;
    healthStatus.lastError = error.message;
    console.error('❌ Lỗi generate ảnh:', error.message);
    res.status(500).json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

app.get('/midjourney/status', async (req, res) => {
  try {
    if (!client) {
      res.json({
        success: false,
        message: 'Client chưa được khởi tạo',
        status: healthStatus.status
      });
      return;
    }

    const authStatus = await client.checkAuthStatus();
    res.json({
      success: true,
      isLoggedIn: authStatus.isLoggedIn,
      status: healthStatus.status,
      uptime: healthStatus.uptime ? Math.floor((Date.now() - healthStatus.uptime) / 1000) : 0
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

app.get('/', (req, res) => {
  res.json({
    message: 'Midjourney API Server',
    version: '1.0.0',
    endpoints: {
      'POST /midjourney/init': 'Khởi tạo client',
      'POST /midjourney/genimage': 'Generate ảnh (POST)',
      'GET /midjourney/genimage': 'Generate ảnh (GET)',
      'GET /midjourney/status': 'Kiểm tra trạng thái',
      'GET /health': 'Health check'
    },
    status: healthStatus.status,
    uptime: healthStatus.uptime ? Math.floor((Date.now() - healthStatus.uptime) / 1000) : 0
  });
});

app.use((error, req, res, next) => {
  console.error('❌ Server error:', error);
  res.status(500).json({
    success: false,
    error: 'Internal server error',
    timestamp: new Date().toISOString()
  });
});

app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Endpoint không tồn tại',
    timestamp: new Date().toISOString()
  });
});

// Memory cleanup function
function cleanupMemory() {
  if (global.gc) {
    global.gc();
    console.log('🧹 Memory cleanup completed');
  }
}

// Periodic memory cleanup (every 30 minutes)
setInterval(cleanupMemory, 30 * 60 * 1000);

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server đang chạy trên port ${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/health`);
  console.log(`🎨 API docs: http://localhost:${PORT}/`);
  
  // Auto-initialize client
  setTimeout(async () => {
    try {
      await initializeClient();
    } catch (error) {
      console.log('⚠️ Không thể tự động khởi tạo client, vui lòng gọi /midjourney/init');
    }
  }, 2000);
});

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);

process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught Exception:', error);
  healthStatus.lastError = error.message;
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
  healthStatus.lastError = reason;
});

module.exports = app; 